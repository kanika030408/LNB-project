# Create class "Student"
class Student:
    # Constructor
    def __init__(self, name, rollno, m1, m2):
        self.name = name
        self.rollno = rollno
        self.m1 = m1
        self.m2 = m2

    # Function to display student details
    def display(self):
        print("Name: ", self.name)
        print("RollNo: ", self.rollno)
        print("Marks1: ", self.m1)
        print("Marks2: ", self.m2)
        print()

# Create a list to store student objects
students = []



while True:
    print("Operations available:")
    print("1. Accept Student details")
    print("2. Display Student Details")
    print("3. Search Details of a Student")
    print("4. Delete Details of Student")
    print("5. Update Student Details")
    print("6. Exit")
    ch = int(input("Enter choice: "))

    if ch == 1:
        # Accept student details
        name = input("Enter name: ")
        rollno = int(input("Enter roll number: "))
        m1 = int(input("Enter marks1: "))
        m2 = int(input("Enter marks2: "))
        student = Student(name, rollno, m1, m2)
        students.append(student)
        print("Student details added.")

    elif ch == 2:
        # Display student details
        print("\nList of Students\n")
        for student in students:
            student.display()

    elif ch == 3:
        x=input("Enter either Name, Rollno to search details:")
        if x=="Rollno" or x=="rollno":
            # Search student details
            rollno = int(input("Enter roll number to search: "))
            found = False
            for student in students:
                if student.rollno == rollno:
                    student.display()
                    found = True
                    break
            if not found:
                print("Student not found.")
        elif x=="Name" or x=="name":
            # Search student details
            name = input("Enter name to search: ")
            found = False
            for student in students:
                if student.name == name:
                    student.display()
                    found = True
                    break
            if not found:
                print("Student not found.")
            
        

    elif ch == 4:
        # Delete student details
        rollno = int(input("Enter roll number to delete: "))
        for student in students:
            if student.rollno == rollno:
                students.remove(student)
                print("Student details deleted.")
                break
        else:
            print("Student not found.")

    elif ch == 5:
        # Update student details
        rollno = int(input("Enter roll number to update: "))
        for student in students:
            if student.rollno == rollno:
                print("Enter new details:")
                name = input("Enter name: ")
                m1 = int(input("Enter marks1: "))
                m2 = int(input("Enter marks2: "))
                student.name = name
                student.m1 = m1
                student.m2 = m2
                print("Student details updated.")
                break
        else:
            print("Student not found.")

    elif ch == 6:
        # Exit the program
        print("Thank You!")
        break

    else:
        print("Invalid choice. Please try again.")
